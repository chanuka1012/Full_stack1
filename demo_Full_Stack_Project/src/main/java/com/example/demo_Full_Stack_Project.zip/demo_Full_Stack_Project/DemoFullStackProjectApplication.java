package com.example.demo_Full_Stack_Project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoFullStackProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoFullStackProjectApplication.class, args);
	}

}
