package com.example.demo_Full_Stack_Project.fullstack.repo;

public interface ReportRepo {

}
